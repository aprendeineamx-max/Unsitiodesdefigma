const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs-extra');
const os = require('os');
const express = require('express');

class MountManager {
    constructor() {
        this.dependencies = null;
        this.isMounted = false;
        this.process = null;
        this.mountPoint = null;
        this.rcloneBin = null;
        this.configPath = null;
        this.startTime = null;
    }

    init(dependencies) {
        this.dependencies = dependencies;
        const { LABS_DIR } = dependencies;

        // Setup Paths
        this.rcloneBin = path.join(__dirname, '../bin/rclone.exe');
        this.mountPoint = path.join(__dirname, '../mnt/cloud');
        this.configPath = path.join(__dirname, '../rclone.conf');

        // Ensure directories exist
        fs.ensureDirSync(path.dirname(this.rcloneBin));
        fs.ensureDirSync(this.mountPoint);

        console.log('[MountManager] Initialized');
        console.log(`[MountManager] Bin: ${this.rcloneBin}`);
        console.log(`[MountManager] Mount: ${this.mountPoint}`);

        // Check for binary
        if (!fs.existsSync(this.rcloneBin)) {
            console.error('[MountManager] rclone.exe not found in server/bin/');
            return false;
        }

        return true;
    }

    // Generate config on the fly from env vars
    async generateConfig() {
        const config = `[vultr]
type = s3
provider = Vultr
access_key_id = ${process.env.VULTR_ACCESS_KEY}
secret_access_key = ${process.env.VULTR_SECRET_KEY}
endpoint = ${process.env.VULTR_ENDPOINT}
acl = private
`;
        await fs.writeFile(this.configPath, config);
        console.log('[MountManager] Config generated');
    }

    async mount() {
        if (this.isMounted) return;
        if (!process.env.VULTR_ACCESS_KEY) {
            console.warn('[MountManager] Skipping mount: credentials missing');
            return;
        }

        try {
            await this.generateConfig();

            // Spawn rclone mount
            // Flags tuned for stability and performance (VFS Cache)
            const args = [
                'mount',
                'vultr:/',
                this.mountPoint,
                '--config', this.configPath,
                '--vfs-cache-mode', 'full',
                '--vfs-cache-max-age', '1h',
                '--dir-cache-time', '30s', // Fast updates check
                '--read-only', // Start safe (optional, remove for write support)
                '--no-console' // Hide popup
            ];

            console.log('[MountManager] Spawning rclone...');
            this.process = spawn(this.rcloneBin, args, {
                stdio: 'ignore', // Detach stdio or use 'pipe' for debug
                detached: false,
                windowsHide: true
            });

            this.process.on('error', (err) => {
                console.error('[MountManager] Process Error:', err);
                this.isMounted = false;
            });

            this.process.on('close', (code) => {
                console.log(`[MountManager] Process exited with code ${code}`);
                this.isMounted = false;
                this.process = null;
            });

            // Allow time to mount
            setTimeout(() => {
                this.isMounted = true;
                this.startTime = Date.now();
                console.log('[MountManager] Mount Successful (Assumed)');
            }, 3000);

        } catch (err) {
            console.error('[MountManager] Mount Failed:', err);
        }
    }

    async unmount() {
        if (this.process) {
            console.log('[MountManager] Unmounting...');
            this.process.kill();
            this.process = null;
            this.isMounted = false;
        }
    }

    getStatus() {
        return {
            available: fs.existsSync(this.rcloneBin),
            mounted: this.isMounted,
            uptime: this.startTime ? (Date.now() - this.startTime) / 1000 : 0,
            mountPoint: this.mountPoint
        };
    }

    isReady() {
        return this.isMounted && fs.existsSync(this.mountPoint);
    }
}

module.exports = new MountManager();
