module.exports = (deps) => {
    return {}; // Dummy monitoring for now
};
